package ch.uzh.ifi.hase.soprafs26.service;

import ch.uzh.ifi.hase.soprafs26.rest.dto.MovieSearchResponseDTO;
import ch.uzh.ifi.hase.soprafs26.rest.dto.OmdbSearchItemDTO;
import ch.uzh.ifi.hase.soprafs26.rest.dto.OmdbSearchResponseDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MovieSearchServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private MovieSearchService movieSearchService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        // Inject fields dynamically
        ReflectionTestUtils.setField(movieSearchService, "apiKey", "test-key");
        ReflectionTestUtils.setField(movieSearchService, "baseUrl", "http://test-url.com/");
        ReflectionTestUtils.setField(movieSearchService, "recommendationUrl", "http://rec-url.com/");

        // Replace the internally instantiated RestTemplate with our mock
        ReflectionTestUtils.setField(movieSearchService, "restTemplate", restTemplate);
    }

    @Test
    public void searchMovies_success() {
        OmdbSearchResponseDTO mockResponse = new OmdbSearchResponseDTO();
        mockResponse.setResponse("True");

        OmdbSearchItemDTO item = new OmdbSearchItemDTO();
        item.setImdbID("tt123");
        item.setTitle("Inception");
        item.setYear("2010");
        mockResponse.setSearch(List.of(item));

        Mockito.when(restTemplate.getForObject(Mockito.any(URI.class), Mockito.eq(OmdbSearchResponseDTO.class)))
                .thenReturn(mockResponse);

        MovieSearchResponseDTO result = movieSearchService.searchMovies("Inception");

        assertNotNull(result);
        assertEquals(1, result.getResults().size());
        assertEquals("tt123", result.getResults().get(0).getId());
        assertEquals("Inception", result.getResults().get(0).getTitle());
        assertEquals(2010, result.getResults().get(0).getYear());
    }

    @Test
    public void searchMovies_nullResponse_throwsException() {
        Mockito.when(restTemplate.getForObject(Mockito.any(URI.class), Mockito.eq(OmdbSearchResponseDTO.class)))
                .thenReturn(null);

        assertThrows(ResponseStatusException.class, () -> movieSearchService.searchMovies("Unknown"));
    }
}